

window.addEventListener(type="DOMContentLoaded",listener=function(){
    let products = document.querySelectorAll(Selectors=".product"),
    buttons = document.querySelectorAll(Selectors="button"),
    openBtn = document.querySelector(Selectors=".open")
    
    function createCart(){
        let cart = document.createElement(tagName="div"),
        field = document.createElement(tagName="div"),
        heading = document.createElement(tagName="h2"),
        closeBtn = document.createElement(tagName="button");
    
        cart.classList.add('cart')
        field.classList.add("cart-field")
        closeBtn.classList.add("close")
    
        heading.textContent="mening moshinam"
        closeBtn.textContent="chiqish"
    
    
        document.body.appendChild(cart)
        cart.appendChild(heading)
        cart.appendChild(field)
        cart.appendChild(closeBtn)
    }
    createCart()
    
    
    let cart = document.querySelector(Selectors=".cart"),
    closeBtn = document.querySelector(Selectors=".close"),
    field = document.querySelector(Selectors=".cart-field");
    
    openBtn.addEventListener(type="click",listener=function(){
        cart.style.display="block"
    })
    closeBtn.addEventListener(type="click",listener=function(){
        cart.style.display="none"
    })
    
    
    buttons.forEach(callbackfn=function(
        item=HTMLButtonElement,i=number){
            item.addEventListener(type="click",listener=function(){
                let cloneItem=products[i].cloneNode(deep=true),
                btn=cloneItem.querySelector(selectors="button");
    
    
                btn.remove()
                field.appendChild(cloneItem)
                products[i].remove()
    
            })
        })
    
    
    
    
    
    
    
    })
    